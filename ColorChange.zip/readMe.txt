I used a promise to make a colro change happen on a delay instead of with callback hell 

i could have also just set the delay to some time and looped through adding a second each iteration? Must try

I added fade so the transition would not be so abrubt 