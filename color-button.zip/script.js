const body = document.body;
const button = document.querySelector('button');
const h1 = document.querySelector('h1');

function colorChange(){
  const R = Math.floor(Math.random() * 256);
  const G = Math.floor(Math.random() * 256);
  const B = Math.floor(Math.random() * 256);
  body.style.backgroundColor = `rgb(${R}, ${G}, ${B})`;
  h1.innerText = `rgb(${R}, ${G}, ${B})`;
}

button.onclick = colorChange;
